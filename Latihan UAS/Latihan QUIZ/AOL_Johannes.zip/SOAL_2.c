#include <stdio.h>
#include <string.h>

struct data{ 
char location[30];
char city[30];
int price;
int room;               // Nama: Johannes Aaron Framon
int bathroom;           // NIM : 2802428223
int carpark;
char type[20];
char furnish[20];
} rumah[4000], selected[4000];
int selectedCount = 0;

// Struct Rumah untuk menampung semua data dari .csv
// Struct selected untuk menampung semua data yang terakhir ditampilkan

void Header(){ // Function untuk tampilan Header
    printf("%-26s", "Location");
    printf("%-20s", "City");
    printf("%-10s", "Price");
    printf("%-10s", "Rooms");
    printf("%-10s", "Bathroom");
    printf("%-10s", "Carpark");
    printf("%-12s", "Type");
    printf("%-12s\n", "Furnish");
}

void print(int j){ // Function untuk print row data
    printf("%-*s", 26, rumah[j].location);
    printf("%-*s", 20, rumah[j].city);
    printf("%-*d", 10, rumah[j].price);
    printf("%-*d", 10, rumah[j].room);
    printf("%-*d", 10, rumah[j].bathroom);
    printf("%-*d", 10, rumah[j].carpark);
    printf("%-*s", 12, rumah[j].type);
    printf("%-*s\n", 12, rumah[j].furnish);
    selected[selectedCount++] = rumah[j];
}

void readFile(int row){ // Function untuk membaca file bernama "file.csv"
    FILE *file;
    file = fopen("file.csv", "r");
    char title[256]; 
    fgets(title, sizeof(title), file);
    
    // Baca sampai row yang diinginkan
    for(int i = 0; i < row; i++){
        if(fscanf(file, "%[^;]; %[^;]; %d; %d; %d; %d; %[^;]; %[^\n]\n",
        rumah[i].location, rumah[i].city, &rumah[i].price, &rumah[i].room, 
        &rumah[i].bathroom, &rumah[i].carpark, rumah[i].type, rumah[i].furnish) == 8){
            // Baca data
        }
    }
    fclose(file);
}

// MENU 1
//==========================================================
void display(){ // Function untuk menampilkan row sebanyak N
    int row = 0;
    printf("Number of rows: ");
    scanf("%d", &row);
    if(row > 3940) row = 3939;
    else if(row <= 0) return;
    readFile(row);
    Header();
    // Tampilkan row yang diinginkan
    for(int i = 0; i < row; i++){
        print(i);
    }
    printf("\n");
}

// MENU 2
// Semua function di bawah ini untuk menampilkan inputan dari void selectRow();
//======================================================

void Location(char Data[]){
    int manggil = 1;
    for(int j = 0; j < 3939; j++){
        if(strcmp(Data, rumah[j].location) == 0){
            if(manggil == 1){
                Header();
                manggil = -1;
            }
            print(j);
        }
    }
    if(manggil == 1) printf("Data not found\n");
}
void City(char Data[]){
    int manggil = 1;
    for(int j = 0; j < 3939; j++){
        if(strcmp(Data, rumah[j].city) == 0){
            if(manggil == 1){
                Header();
                manggil = -1;
            }
            print(j);
        }
    }
    if(manggil == 1) printf("Data not found\n");
}
void Price(int Data){
    int manggil = 1;
    for(int j = 0; j < 3939; j++){
        if(Data == rumah[j].price){
            if(manggil == 1){
                Header();
                manggil = -1;
            }
            print(j);
        }
    }
    if(manggil == 1) printf("Data not found\n");
}
void Rooms(int Data){
    int manggil = 1;
    for(int j = 0; j < 3939; j++){
        if(Data == rumah[j].room){
            if(manggil == 1){
                Header();
                manggil = -1;
            }
            print(j);
        }
    }
    if(manggil == 1) printf("Data not found\n");
}
void Bathroom(int Data){
    int manggil = 1;
    for(int j = 0; j < 3939; j++){
        if(Data == rumah[j].bathroom){
            if(manggil == 1){
                Header();
                manggil = -1;
            }
            print(j);
        }
    }
    if(manggil == 1) printf("Data not found\n");
}
void Carpark(int Data){
    int manggil = 1;
    for(int j = 0; j < 3939; j++){
        if(Data == rumah[j].carpark){
            if(manggil == 1){
                Header();
                manggil = -1;
            }
            print(j);
        }
    }
    if(manggil == 1) printf("Data not found\n");
}
void Type(char Data[]){
    int manggil = 1;
    for(int j = 0; j < 3939; j++){
        if(strcmp(Data, rumah[j].type) == 0){
            if(manggil == 1){
                Header();
                manggil = -1;
            }
            print(j);
        }
    }
    if(manggil == 1) printf("Data not found\n");
}
void Furnish(char Data[]){
    int manggil = 1;
    for(int j = 0; j < 3939; j++){
        if(strcmp(Data, rumah[j].furnish) == 0){
            if(manggil == 1){
                Header();
                manggil = -1;
            }
            print(j);
        }
    }
    if(manggil == 1) printf("Data not found\n");
}

void selectRow(){ // Function untuk input column dan data
    readFile(3939);
    char column[10] = {0};
    char DataString[20] = {0};
    int DataInteger = 0;
    printf("Choose column: ");
    scanf("%[^\n]", column); getchar();

    // Selection tergantung Column yang diinput + memanggil function di atas
    if(strcmp(column, "Location") == 0){
        printf("What do you want to find?: ");
        scanf("%[^\n]", DataString);
        printf("Data found! Here's the details:\n");
        Location(DataString);
    }
    else if(strcmp(column, "City") == 0){
        printf("What do you want to find?: ");
        scanf("%[^\n]", DataString);
        printf("Data found! Here's the details:\n");
        City(DataString);
    }
    else if(strcmp(column, "Price") == 0){
        printf("What do you want to find?: ");
        scanf("%d", &DataInteger);
        printf("Data found! Here's the details:\n");
        Price(DataInteger);
    }
    else if(strcmp(column, "Rooms") == 0){
        printf("What do you want to find?: ");
        scanf("%d", &DataInteger);
        printf("Data found! Here's the details:\n");
        Rooms(DataInteger);
    }
    else if(strcmp(column, "Bathroom") == 0){
        printf("What do you want to find?: ");
        scanf("%d", &DataInteger);
        printf("Data found! Here's the details:\n");
        Bathroom(DataInteger);
    }
    else if(strcmp(column, "Carpark") == 0){
        printf("What do you want to find?: ");
        scanf("%d", &DataInteger);
        printf("Data found! Here's the details:\n");
        Carpark(DataInteger);
    }
    else if(strcmp(column, "Type") == 0){
        printf("What do you want to find?: ");
        scanf("%[^\n]", DataString);
        printf("Data found! Here's the details:\n");
        Type(DataString); 
    }
    else if(strcmp(column, "Furnish") == 0){
        printf("What do you want to find?: ");
        scanf("%[^\n]", DataString);
        printf("Data found! Here's the details:\n");
        Furnish(DataString);
    }
    else printf("Data not found\n");
}

// MENU 3
//========================================================
void urut(int j){ // Function ini untuk mensortir semua data (tergantung inputan)
    char temp0[30] = {0};
    strcpy(temp0, rumah[j].location);
    strcpy(rumah[j].location, rumah[j-1].location);
    strcpy(rumah[j-1].location, temp0);

    char temp1[30] = {0};
    strcpy(temp1, rumah[j].city);
    strcpy(rumah[j].city, rumah[j-1].city);
    strcpy(rumah[j-1].city, temp1);

    int temp2 = rumah[j].price;
    rumah[j].price = rumah[j - 1].price;
    rumah[j - 1].price = temp2;

    int temp3 = rumah[j].room;
    rumah[j].room = rumah[j - 1].room;
    rumah[j - 1].room = temp3;

    int temp4 = rumah[j].bathroom;
    rumah[j].bathroom = rumah[j - 1].bathroom;
    rumah[j - 1].bathroom = temp4;

    int temp5 = rumah[j].carpark;
    rumah[j].carpark = rumah[j - 1].carpark;
    rumah[j - 1].carpark = temp5;

    char temp6[30] = {0};
    strcpy(temp6, rumah[j].type);
    strcpy(rumah[j].type, rumah[j-1].type);
    strcpy(rumah[j-1].type, temp6);

    char temp7[30] = {0};
    strcpy(temp7, rumah[j].furnish);
    strcpy(rumah[j].furnish, rumah[j-1].furnish);
    strcpy(rumah[j-1].furnish, temp7);
}

// Semua function di bawah ini untuk mensortir data (ascending /descending)
//======================================================================
void sortLokasi(char sorting[]){
    if(strcmp(sorting, "asc") == 0){
        for(int i = 0; i < 3939; i++){
            for(int j = 3939 - 1; j > i; j--){
                if(strcmp(rumah[j].location, rumah[j-1].location) < 0){
                    urut(j);
                }
            }
        }
    }
    else if(strcmp(sorting, "desc") == 0){
        for(int i = 0; i < 3939; i++){
            for(int j = 3939 - 1; j > i; j--){
                if(strcmp(rumah[j].location, rumah[j-1].location) > 0){
                    urut(j);
                }
            }
        }
    }
}
void sortCity(char sorting[]){
    if(strcmp(sorting, "asc") == 0){
        for(int i = 0; i < 3939; i++){
            for(int j = 3939 - 1; j > i; j--){
                if(strcmp(rumah[j].city, rumah[j-1].city) < 0){
                    urut(j);
                }
            }
        }
    }
    else if(strcmp(sorting, "desc") == 0){
        for(int i = 0; i < 3939; i++){
            for(int j = 3939 - 1; j > i; j--){
                if(strcmp(rumah[j].city, rumah[j-1].city) > 0){
                    urut(j);
                }
            }
        }
    }
}
void sortPrice(char sorting[]){
    if(strcmp(sorting, "asc") == 0){
        for(int i = 0; i < 3939; i++){
            for(int j = 3939 - 1; j > i; j--){
                if(rumah[j].price < rumah[j-1].price){
                    urut(j);
                }
            }
        }
    }
    else if(strcmp(sorting, "desc") == 0){
        for(int i = 0; i < 3939; i++){
            for(int j = 3939 - 1; j > i; j--){
                if(rumah[j].price > rumah[j-1].price){
                    urut(j);
                }
            }
        }
    }
}
void sortRoom(char sorting[]){
    if(strcmp(sorting, "asc") == 0){
        for(int i = 0; i < 3939; i++){
            for(int j = 3939 - 1; j > i; j--){
                if(rumah[j].room < rumah[j-1].room){
                    urut(j);
                }
            }
        }
    }
    else if(strcmp(sorting, "desc") == 0){
        for(int i = 0; i < 3939; i++){
            for(int j = 3939 - 1; j > i; j--){
                if(rumah[j].room > rumah[j-1].room){
                    urut(j);
                }
            }
        }
    }
}
void sortBath(char sorting[]){
    if(strcmp(sorting, "asc") == 0){
        for(int i = 0; i < 3939; i++){
            for(int j = 3939 - 1; j > i; j--){
                if(rumah[j].bathroom < rumah[j-1].bathroom){
                    urut(j);
                }
            }
        }
    }
    else if(strcmp(sorting, "desc") == 0){
        for(int i = 0; i < 3939; i++){
            for(int j = 3939 - 1; j > i; j--){
                if(rumah[j].bathroom > rumah[j-1].bathroom){
                    urut(j);
                }
            }
        }
    }
}
void sortCar(char sorting[]){
    if(strcmp(sorting, "asc") == 0){
        for(int i = 0; i < 3939; i++){
            for(int j = 3939 - 1; j > i; j--){
                if(rumah[j].carpark < rumah[j-1].carpark){
                    urut(j);
                }
            }
        }
    }
    else if(strcmp(sorting, "desc") == 0){
        for(int i = 0; i < 3939; i++){
            for(int j = 3939 - 1; j > i; j--){
                if(rumah[j].carpark > rumah[j-1].carpark){
                    urut(j);
                }
            }
        }
    }
}
void sortType(char sorting[]){
    if(strcmp(sorting, "asc") == 0){
        for(int i = 0; i < 3939; i++){
            for(int j = 3939 - 1; j > i; j--){
                if(strcmp(rumah[j].type, rumah[j-1].type) < 0){
                    urut(j);
                }
            }
        }
    }
    else if(strcmp(sorting, "desc") == 0){
        for(int i = 0; i < 3939; i++){
            for(int j = 3939 - 1; j > i; j--){
                if(strcmp(rumah[j].type, rumah[j-1].type) > 0){
                    urut(j);
                }
            }
        }
    }
}
void sortFurnish(char sorting[]){
    if(strcmp(sorting, "asc") == 0){
        for(int i = 0; i < 3939; i++){
            for(int j = 3939 - 1; j > i; j--){
                if(strcmp(rumah[j].furnish, rumah[j-1].furnish) < 0){
                    urut(j);
                }
            }
        }
    }
    else if(strcmp(sorting, "desc") == 0){
        for(int i = 0; i < 3939; i++){
            for(int j = 3939 - 1; j > i; j--){
                if(strcmp(rumah[j].furnish, rumah[j-1].furnish) > 0){
                    urut(j);
                }
            }
        }
    }
}

// Function untuk menampilkan 10 row data berdasarkan sortingan
void tampilkan(){
    for(int x = 0; x < 10; x++){
        print(x);
    }
}

void sortBy(){ // Function untuk mensortir data dari kolom yang diinginkan
    readFile(3939);
    char kolom[20] = {0};
    char sorting[5] = {0};
    printf("Choose column: ");
    scanf("%[^\n]", kolom); getchar();

    // Pengecekan apakah kolom sesuai dengan data
    if(strcmp(kolom, "Location") == 0 || strcmp(kolom, "City") == 0
    || strcmp(kolom, "Price") == 0 || strcmp(kolom, "Rooms") == 0
    || strcmp(kolom, "Bathroom") == 0 || strcmp(kolom, "Carpark") == 0
    || strcmp(kolom, "Type") == 0 || strcmp(kolom, "Furnish") == 0){
        printf("Sort ascending or descending? (asc / desc): ");
        scanf("%s", sorting);
        printf("Data found! Here's the details:\n");
    }
    else{
        printf("Data not found\n");
        return;
    }
    // Pemanggilan kumpulan function berdasarkan kolom yang diinginkan
    if(strcmp(kolom, "Location") == 0){
        sortLokasi(sorting);
        Header();
        tampilkan();
    }
    else if(strcmp(kolom, "City") == 0){
        sortCity(sorting);
        Header();
        tampilkan();
    }
    else if(strcmp(kolom, "Price") == 0){
        sortPrice(sorting);
        Header();
        tampilkan();
    }
    else if(strcmp(kolom, "Rooms") == 0){
        sortRoom(sorting);
        Header();
        tampilkan();
    }
    else if(strcmp(kolom, "Bathroom") == 0){
        sortBath(sorting);
        Header();
        tampilkan();
    }
    else if(strcmp(kolom, "Carpark") == 0){
        sortCar(sorting);
        Header();
        tampilkan();
    }
    else if(strcmp(kolom, "Type") == 0){
        sortType(sorting);
        Header();
        tampilkan(); 
    }
    else if(strcmp(kolom, "Furnish") == 0){
        sortFurnish(sorting);
        Header();
        tampilkan(); 
    }
}

// MENU 4
//=========================================================
void writeFile(struct data selected[], int selectedCount){
    char nama[100]; // Function untuk menulis semua data yang terakhir
    printf("Please dont use space or any special character in your file name\n");
    printf("File name: ");
    scanf("%s", nama);

    if(strstr(nama, ".csv") == NULL) strcat(nama, ".csv");
    FILE *file = fopen(nama, "w");
    fprintf(file, "Location,City,Price,Rooms,Bathroom,Carpark,Type,Furnish\n");   

    for(int i = 0; i < selectedCount; i++){
        fprintf(file, "%s,%s,%d,%d,%d,%d,%s,%s\n", selected[i].location,
        selected[i].city, selected[i].price, selected[i].room, selected[i].bathroom,
        selected[i].carpark, selected[i].type, selected[i].furnish);
    }
    printf("Data succesfully written into %s!\n", nama);
    fclose(file);
}

void setZero(){ // Function untuk set struct tampungan ke 0
    memset(selected, 0, sizeof(selected));
    selectedCount = 0;
}

// INT MAIN
//======================================================
int main(){
    int choice = 0;
    do{
        // Tampilan menu utama yang akan looping sampai EXIT
        printf("\nWhat do you want to do?\n");
        printf("1. Display Data\n");
        printf("2. Search Data\n");
        printf("3. Sort Data\n");
        printf("4. Export Data\n");
        printf("5. Exit\n");
        printf("Your choice: ");
        scanf("%d", &choice); getchar();
        // Memanggil function sesuai yang diminta
        switch(choice){
            case 1:{
                setZero();
                display();
                break;
            }
            case 2:{
                setZero();
                selectRow();
                break;
            }
            case 3:{
                setZero();
                sortBy();
                break;
            }
            case 4:{
                writeFile(selected, selectedCount);
                setZero();
                break;
            }
        }
    }while(choice != 5);
    printf("        _______   _   _    ___    __     _   _   __  ___         \n");
    printf("       |__   __| | | | |  / _ \\  |  \\   | | | | / / | __|      \n");
    printf("          | |    | |_| | | |_| | | |\\\\  | | | |/ /  \\ \\      \n");
    printf("          | |    |  _  | |  _  | | | \\\\ | | |   |    \\ \\     \n");
    printf("          | |    | | | | | | | | | |  \\\\| | | |\\ \\   _\\ \\  \n");
    printf("          |_|    |_| |_| |_| |_| |_|   \\__| |_| \\_\\ |___|     \n");

    printf("                      _____   _____   ____         \n");
    printf("                     |  ___| |  _  | |  _ \\       \n");                 
    printf("                     | |___  | | | | | |_| |       \n");
    printf("                     |  ___| | | | | |    /        \n");
    printf("                     | |     | |_| | | |\\ \\      \n");
    printf("                     |_|     |_____| |_| \\_\\     \n");

    printf("  _        _    _    ___   _   _______   _    __     _     _____                 \n");
    printf(" | \\      / |  | |  | __| | | |__   __| | |  |  \\   | |   / ____|              \n");
    printf("  \\ \\    / /   | |  \\ \\   | |    | |    | |  | |\\\\  | |  | | ____            \n");
    printf("   \\ \\  / /    | |   \\ \\  | |    | |    | |  | | \\\\ | |  | | \\__ \\         \n");
    printf("    \\ \\/ /     | |   _\\ \\ | |    | |    | |  | |  \\\\| |  | \\___/ /          \n");
    printf("     \\__/      |_|  |___| |_|    |_|    |_|  |_|   \\__|   \\_____/               \n");
    return 0;
}